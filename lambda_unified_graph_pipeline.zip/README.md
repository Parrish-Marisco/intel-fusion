
# Lambda pipeline for unified_graph.json

This Lambda reads:
- input/entities.csv
- input/reports.csv
- input/edges.csv

It writes:
- output/unified_graph.json

## Deploy
1. Create an S3 bucket.
2. Upload the three CSVs into `input/`.
3. Create a Lambda function using Python 3.12.
4. Paste in `lambda_function.py`.
5. Give the Lambda role `s3:GetObject` and `s3:PutObject`.

## Test event
```json
{
  "bucket": "YOUR_BUCKET_NAME",
  "entities_key": "input/entities.csv",
  "reports_key": "input/reports.csv",
  "edges_key": "input/edges.csv",
  "output_key": "output/unified_graph.json"
}
```
